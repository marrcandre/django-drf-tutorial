#! /bin/bash

cd ~/

wget https://dl.pstmn.io/download/latest/linux64 -O postman.tar.gz
tar -xzf postman.tar.gz -C .

cat << EOF > ~/.local/share/applications/Postman.desktop  
[Desktop Entry]
Name=Postman
Exec=/home/aluno/Postman/Postman
Comment=Postman
Terminal=false
Icon=/home/aluno/Postman/app/icons/icon_128x128.png
Type=Application
Categories=Development
EOF

# Optional: remove downloaded file
rm postman.tar.gz
