from django.contrib import admin

from media.models import Image, Document

admin.site.register(Image)
admin.site.register(Document)
